%{
#include<stdio.h>
#include<stdlib.h>

int yylex();
int yyerror();
%}

%token NUM
%left '+' '-'
%left '*' '/'


%%
S: E {printf("Result : %d",$1 );}
E: E '+' E {$$=$1+$3;}
 | E '-' E {$$=$1-$3;}
 | E '*' E {$$=$1*$3;}
 | E '/' E {$$=$1/$3;}
 | '(' E ')' {$$=$2;} 
 | NUM {$$=$1;}
 ;
%%

int main(){yyparse();return 0;}
int yyerror(){printf("Invalid\n"); exit(0);}