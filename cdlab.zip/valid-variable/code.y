%{
#include<stdio.h>
#include<stdlib.h>
int yylex();
int yyerror();
%}

%token ID

%%
S : ID
  ;
%%

int main(){yyparse(); printf("Valid\n"); return 0;}
int yyerror(){printf("Invalid\n"); exit(0);}