%{
#include<stdio.h>
#include<stdlib.h>
int yylex();
int yyerror();
%}

%token ID
%left '+' '-'
%left '*' '/'

%%
E: E '+' E | E '-' E | E '*' E | E '/' E | '(' E ')' | ID;
%%

int main(){yyparse(); printf("Valid\n"); return 0;}
int yyerror(){printf("Invald\n"); exit(0);}