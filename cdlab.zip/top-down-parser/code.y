%{
#include<stdio.h>
#include<stdlib.h>
int yylex();
int yyerror();
%}

%token A
%token B

%%
S: A S B | ;
%%

int main(){yyparse(); printf("Valid\n"); return 0;}
int yyerror(){printf("Invalid\n"); exit(0);}