#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main(){
    char ch,str[200];
    FILE *fp=fopen("my-symbol-table.c","r");
    if(!fp)return 1;
    while((ch=fgetc(fp))!=EOF){
        if(isalpha(ch)){
            int i=0;
            str[i++]=ch;
            while(isalnum(ch=fgetc(fp)))str[i++]=ch;
            str[i]='\0';
            printf("\nidentifier : %s",str);
        }
        else if(isdigit(ch)){
            int i=0;
            str[i++]=ch;
            while(isdigit(ch=fgetc(fp)))str[i++]=ch;
            str[i]='\0';
            printf("\nconstant : %s",str);
        }
        else if(ch=='/'&&(ch=fgetc(fp))=='/'){
            int i=0;
            while((ch=fgetc(fp))!='\n')str[i++]=ch;
            str[i]='\0';
            printf("\ncomment : %s",str);
        }
        else if(ch=='+'||ch=='-'||ch=='*'||ch=='/'||ch=='='){
            printf("\noperator : %c",ch);
        }
    }
    fclose(fp);
    return 0;
}
