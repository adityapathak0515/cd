#include <stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
struct tb{
    int val;
    char symbol[10];
};
struct tb tab[20];
int i=0;
int main(){
    int choice;
    printf("\nEnter choice 1.insert 2.modify 3.search 4.exit\n");
    scanf("%d",&choice);
    while(choice!=4){
        if(choice==1){
            insert();
        }
        else if(choice==2){
            modify();
        }
        else if(choice==3){
            search();
        }
        else{
            printf("\nInvalid choice");
        }
        printf("\nEnter choice 1.insert 2.modify 3.search 4.exit\n");
        scanf("%d",&choice);
        display();
    }
    return 0;
}
void insert(){
    if(i==19){
        printf("\nFull");
        return;
    }
    else{
        int val;
        char sym[10];
        printf("\nEnter name n num: ");
        scanf("%s%d",sym,&val);
        int j;
        for(j=0;j<i;j++){
            if(strcmp(sym,tab[j].symbol)==0){
                printf("\nExists");
                return;
            }
        }
        tab[i].val=val;
        strcpy(tab[i].symbol,sym);
        i++;
    }
    display();
}
void modify(){
    printf("\nEnter symbol name and new value:");
    char sym[10];
    int val;
    scanf("%s%d",sym,&val);
    int j;
    for(j=0;j<i;j++){
        if(strcmp(tab[j].symbol,sym)==0){
            break;
        }
    }
    if(j==i){
        printf("\nNot Found");
        return;
    }
    tab[j].val=val;
    display();
}
void search(){
    printf("\nEnter symbol name to search:");
    char sym[10];
    scanf("%s",sym);
    int j;
    for(j=0;j<i;j++){
        if(strcmp(tab[j].symbol,sym)==0){
            break;
        }
    }
    if(j==i){
        printf("\nNot Found");
        return;
    }
    else{
        printf("\nfound at %d index",j+1);
    }
    display();
}
void display(){
    int j;
    printf("\nSymbol----value");
    for(j=0;j<i;j++){
        printf("\n%s----%d",tab[j].symbol,tab[j].val);
    }
}
