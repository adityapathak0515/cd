#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int i;
char input[20];
int l();
int s();
int ldash();
int s(){
    if(input[i]=='('){
        i++;
        if(l()){
            if(input[i]==')'){
                i++;
                return 1;
            }
            return 0;
        }
        return 0;
    }
    if(input[i]=='a'){
        i++;
        return 1;
    }
    return 0;
}
int l(){
    if(s()){
        return ldash();
    }
    return 0;
}
int ldash(){
    if(input[i]==','){
        i++;
        if(s()){
            return ldash();
        }
        return 0;
    }
    return 1;
}
void main(){
    printf("Enter: ");
    i=0;
    scanf("%s",input);
    s();
    if(input[i]=='\0'){
        printf("\nGood");
    }
    else printf("\nLOL");
}
