#include<stdio.h>
#include<String.h>
#include<stdlib.h>
char prods[20][20]={
    "e=e+t",
    "e=t",
    "t=t*f",
    "t=f",
    "f=(e)",
    "f=I"
};
//E->E+T
//E->T
//T->T*F
//T->F
//F->(E)/id
void first(char c);
void first(char c){
    if(isupper(c)||!isalpha(c)){
        printf("%c, ",c);
        return;
    }
    int i=0;
    for(i=0;i<6;i++){
        if(prods[i][0]==c){
            if(prods[i][2]!=c)
            first(prods[i][2]);
        }
    }
}

int main(){
    printf("first(E)={ ");
    first('e');
    printf("}\n");
    printf("first(T)={ ");
    first('t');
    printf("}\n");
    printf("first(F)={ ");
    first('f');
    printf("}\n");
}
